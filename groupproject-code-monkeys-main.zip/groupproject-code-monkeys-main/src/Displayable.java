//import java.util.ArrayList;
//import acm.graphics.GObject;

public interface Displayable {
	public void showContents();
	public void hideContents();
	
}
